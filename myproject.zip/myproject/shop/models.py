from django.db import models
from django.contrib.auth.models import User
#from django.utils.timezone

# Create your models here.
class Users(models.Model):
    username=models.CharField(max_length=255,primary_key=True,unique=True)
    fullname=models.CharField(max_length=255)
    email=models.CharField(max_length=255,unique=True)
    password=models.CharField(max_length=255,unique=True)
    phone_number=models.IntegerField(unique=True)

class Product(models.Model):
    id=models.IntegerField(primary_key=True,unique=True)
    name=models.CharField(max_length=255,unique=True)
    sugar=models.IntegerField()
    coffee=models.IntegerField()
    flour=models.IntegerField()
    chocolate=models.IntegerField()
    vertical=models.CharField(max_length=255)
    price=models.IntegerField()
    sales=models.IntegerField(default=0)
    image=models.ImageField(default=None,upload_to='upload/product/')
    def __str__(self):
        return self.name
class Order(models.Model):
    order_id=models.IntegerField(primary_key=True,unique=True)
    username=models.CharField(max_length=255)
    products=models.CharField(max_length=255)
    purchase_amount=models.IntegerField()
    type=models.BinaryField()
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    user=models.ForeignKey(Users,default='',on_delete=models.CASCADE)
    #date=models.DateField(default=datetime.datetime.today())
    def __str__(self):
        return self.product

class Admins(models.Model):
    username=models.CharField(max_length=255,primary_key=True,unique=True)
    email=models.CharField(max_length=255,unique=True)
    password=models.CharField(max_length=255,unique=True)
class Storage(models.Model):
    id=models.IntegerField(primary_key=True,unique=True)
    name=models.CharField(max_length=255,unique=True)
    amount=models.IntegerField()
