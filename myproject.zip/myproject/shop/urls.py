from django.urls import path,include
from .views import *
from django.conf.urls.static import static
from django.conf import settings
urlpatterns = [    
    path('',home,name='home'),
    path('signin/',signin,name='signin'),
    path('login/',login_view,name='login'),
    path('logout/',logout_view,name='logout'),
    path('manage/',manage_view,name='manage'),
    path('manageinventory/',manage_inventory,name='manageinventory'),
    path('purchasehistory/',purchase_view,name='purchasehistory'),
    path('card/',card_view,name='card'),
    path('add_product/',add_product,name='add_product'),
    path('products/',products_view,name='products')
]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)