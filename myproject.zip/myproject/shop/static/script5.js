$(document).ready(function() {
    // بارگیری مقادیر موجودی از حافظه محلی
    loadInventory();

    // ذخیره مقادیر موجودی در حافظه محلی
    $('#inventory-form').submit(function(e) {
        e.preventDefault();
        saveInventory();
        Swal.fire({
            icon: 'success',
            title: 'موجودی با موفقیت ذخیره شد',
            showConfirmButton: false,
            timer: 1500
        });
    });
});

function loadInventory() {
    // بارگیری مقادیر موجودی از حافظه محلی و قرار دادن آن‌ها در فرم
    var sugar = localStorage.getItem('sugar') || 0;
    var coffee = localStorage.getItem('coffee') || 0;
    var flour = localStorage.getItem('flour') || 0;
    var chocolate = localStorage.getItem('chocolate') || 0;

    $('#sugar').val(sugar);
    $('#coffee').val(coffee);
    $('#flour').val(flour);
    $('#chocolate').val(chocolate);
}

function saveInventory() {
    // ذخیره مقادیر موجودی در حافظه محلی
    var sugar = $('#sugar').val();
    var coffee = $('#coffee').val();
    var flour = $('#flour').val();
    var chocolate = $('#chocolate').val();

    localStorage.setItem('sugar', sugar);
    localStorage.setItem('coffee', coffee);
    localStorage.setItem('flour', flour);
    localStorage.setItem('chocolate', chocolate);
}