$(document).ready(function() {
    $('#product-form').submit(function(e) {
        e.preventDefault();
        saveProduct();
        Swal.fire({
            icon: 'success',
            title: 'محصول با موفقیت اضافه شد',
            showConfirmButton: false,
            timer: 1500
        });
        resetForm();
    });
});

function saveProduct() {
    var productName = $('#product-name').val();
    var ingredients = $('#ingredients').val();
    var category = $('#category').val();
    var price = $('#price').val();
    var image = $('#image').val();

    // ارسال اطلاعات به سرور و ذخیره در پایگاه داده

    console.log('نام محصول: ' + productName);
    console.log('مواد اولیه: ' + ingredients);
    console.log('دسته بندی: ' + category);
    console.log('قیمت: ' + price);
    console.log('تصویر: ' + image);
}

function resetForm() {
    $('#product-name').val('');
    $('#ingredients').val('');
    $('#category').val('food');
    $('#price').val('');
    $('#image').val('');
}