document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let fullname = document.getElementById('fullname').value;
    let username = document.getElementById('username').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;
    let phone = document.getElementById('phone').value;
    
    // اینجا می‌توانید اطلاعات را به سرور ارسال کنید و حساب کاربری را ایجاد کنید
    
    alert('حساب کاربری با موفقیت ایجاد شد!');
});