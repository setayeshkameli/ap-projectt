
    // Initialize an empty cart array
    const cartItems = [];

    // Function to add a product to the cart
    function addToCart(product) {
        cartItems.push(product);
        updateCartDisplay();
    }

    // Function to update the cart display
    function updateCartDisplay() {
        const cartTableBody = document.getElementById('cart-items');
        cartTableBody.innerHTML = ''; // Clear existing items

        cartItems.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.product.name}</td>
                <td>${item.product.ingredients}</td>
                <td>${item.quantity}</td>
                <td>${item.product.price}</td>
                <td>${item.product.price * item.quantity}</td>
            `;
            cartTableBody.appendChild(row);
        });

        // Calculate and display the total price
        const totalPrice = cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0);
        // Update the total price display element (if you have one)
    }

    // Event listener for the "Add to Cart" button
    document.getElementById('add-to-cart-btn').addEventListener('click', () => {
        const selectedProduct = {
            product: {
                name: 'Product Name', // Replace with actual product data
                ingredients: 'Ingredients',
                price: 100, // Replace with actual price
            },
            quantity: 1, // You can adjust this based on user input
        };
        addToCart(selectedProduct);
    });

    // Event listener for the checkout button
    document.getElementById('checkout-btn').addEventListener('click', () => {
        // Handle checkout logic (e.g., redirect to payment page)
    });

