from django import forms
from.models import Users
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class SigninForm(UserCreationForm):
  fullname=forms.CharField(label='',max_length=255,widget=forms.TextInput(attrs={'class':'form-control' ,"placeholder":"نام و نام خانوادگی"}))
  username=forms.CharField(label='',max_length=255,widget=forms.TextInput(attrs={'class':'form-control' ,"placeholder":"نام کاربری"}))
  email=forms.CharField(label='',max_length=255,widget=forms.TextInput(attrs={'class':'form-control' ,"placeholder":"ایمیل"}))
  password=forms.CharField(label='',max_length=255,widget=forms.TextInput(attrs={'class':'form-control',"placeholder":"رمز عبور ثابت"}))
  class Meta:
    model =User
    fields=['username','fullname','email','password']

class LoginForm(forms.Form):
  username_or_email=forms.CharField(label='نام کاربری یا ایمیل')
  password=forms.CharField(widget=forms.PasswordInput,label='رمز عبور')
