document.getElementById('product-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let productName = document.getElementById('product-name').value;
    let rawMaterials = document.getElementById('raw-materials').value;
    let category = document.getElementById('category').value;
    let price = document.getElementById('price').value;
    let productImage = document.getElementById('product-image').files[0];

    let reader = new FileReader();
    reader.onload = function(e) {
        let productImageURL = e.target.result;

        let productListItem = document.createElement('li');

        let productImageElement = document.createElement('img');
        productImageElement.src = productImageURL;

        let productInfo = document.createElement('div');
        productInfo.innerHTML = `
            <strong>${productName}</strong><br>
            مواد اولیه: ${rawMaterials}<br>
            دسته: ${category}<br>
            قیمت: تومان${price}
        `;

        productListItem.appendChild(productImageElement);
        productListItem.appendChild(productInfo);

        document.getElementById('product-list').appendChild(productListItem);

        // Clear the form
        document.getElementById('product-form').reset();
    }

    reader.readAsDataURL(productImage);
});
