document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Capture user inputs
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simple client-side validation
    if (username === '' || password === '') {
        document.getElementById('message').innerText = 'پر کردن همه فیلد ها الزامی است';
        return;
    }

    // Mock login functionality
    if (username === 'user' && password === 'password') {
        document.getElementById('message').innerText = 'ورود با موفقیت انجام شد';
        document.getElementById('message').style.color = 'green';
    } else {
        document.getElementById('message').innerText = 'نام کاربری و یا رمز عبور اشتباه است';
    }
});
