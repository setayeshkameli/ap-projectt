document.addEventListener("DOMContentLoaded", () => {
    const categories = {
        "hot-drinks": "نوشیدنی گرم",
        "cold-drinks": "نوشیدنی سرد",
        "cakes": "کیک‌ها"
    };

    const products = {
        "hot-drinks": [
            { name: "اسپرسو", price: 25, image: "spresso.jpg" },
            { name: "لاته", price: 30, image: "latte.jpg" },
            { name: "کاپوچینو", price: 35, image: "cupoccino.webp" },
            { name: "چای", price: 27, image: "tea.jpg" },
            { name: "موکا", price: 37, image: "mocha.webp" },
            { name: "قهوه ترک", price: 32, image: "turk.jpg" }
        ],
        "cold-drinks": [
            { name: "آیس کافی", price: 30, image: "icecoffee.jpg" },
            { name: "آفوگاتو", price: 35, image: "affogatto.jpg" },
            { name: "آیس لته", price: 37, image: "icelatte.jpeg" },
            { name: "آیس موکا", price: 40, image: "icemocha.jpg"},
            { name: "موهیتو", price: 32, image: "mohito.jpg" },
            { name: "میلک شیک", price: 45, image: "milkshake.jpg" }
        ],
        "cakes": [
            { name: "کیک شکلاتی", price: 40, image: "chocolate.jpg" },
            { name: "کیک هویج", price: 45, image: "carrot.jpg" },
            { name: "موچی", price: 42, image: "mochi.jpg" },
            { name: "ترامیسو", price: 47, image: "tramiso.webp" },
            { name: "پای سیب", price: 40, image: "applepie.jpg" },
            { name: "چیزکیک", price: 45, image: "chescake.jpg" }
        ]
    };

    // Load additional products from localStorage
    const additionalProducts = JSON.parse(localStorage.getItem('products')) || [];

    additionalProducts.forEach(product => {
        const categoryKey = Object.keys(categories).find(key => categories[key] === product.category);
        if (categoryKey) {
            if (!products[categoryKey]) {
                products[categoryKey] = [];
            }
            products[categoryKey].push(product);
        }
    });

    for (const category in products) {
        const productGrid = document.querySelector(`#${category} .product-grid`);
        products[category].forEach(product => {
            const productCard = document.createElement("div");
            productCard.classList.add("product-card");

            const productImage = document.createElement("img");
            productImage.src = product.image;
            productImage.alt = product.name;

            const productInfo = document.createElement("div");
            productInfo.classList.add("product-info");

            const productName = document.createElement("h3");
            productName.textContent = product.name;

            const productPrice = document.createElement("p");
            productPrice.textContent = `تومان${product.price}`;

            const addToCartButton = document.createElement("button");
            addToCartButton.textContent = "افزودن به سبد خرید";
            addToCartButton.addEventListener("click", () => {
                addToCart(product);
                window.location.href = "cart.html";
            });

            productInfo.appendChild(productName);
            productInfo.appendChild(productPrice);
            productInfo.appendChild(addToCartButton);
            productCard.appendChild(productImage);
            productCard.appendChild(productInfo);
            productGrid.appendChild(productCard);
        });
    }

    function addToCart(product) {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const existingProductIndex = cart.findIndex(item => item.name === product.name);

        if (existingProductIndex >= 0) {
            cart[existingProductIndex].quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
    }

    // Scroll to the target section based on local storage
    const targetSection = localStorage.getItem('targetSection');
    if (targetSection) {
        const sectionElement = document.querySelector(`[data-section="${targetSection}"]`);
        if (sectionElement) {
            sectionElement.scrollIntoView({ behavior: 'smooth' });
            localStorage.removeItem('targetSection');
        }
    }
});
