document.addEventListener('DOMContentLoaded', () => {
    const orderHistoryContainer = document.getElementById('order-history');

    function renderOrderHistory() {
        orderHistoryContainer.innerHTML = '';
        const orders = JSON.parse(localStorage.getItem('orders')) || [];

        if (orders.length === 0) {
            orderHistoryContainer.innerHTML = '<p>شما سفارشات قبلی ندارید.</p>';
            return;
        }

        orders.forEach((order, index) => {
            const orderElement = document.createElement('div');
            orderElement.classList.add('order-item');

            orderElement.innerHTML = `
                <p>سفارش ${index + 1}: ${order.name} (x${order.quantity}) - ${order.date}</p>
            `;

            orderHistoryContainer.appendChild(orderElement);
        });
    }

    renderOrderHistory();
});
