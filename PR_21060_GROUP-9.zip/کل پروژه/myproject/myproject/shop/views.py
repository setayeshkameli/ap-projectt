
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate,login,logout
from .forms import RegisterForm,ProductForm,CategoryForm,RawMaterialForm,LoginForm,OrderTypeForm
from django.contrib import messages
from .models import RawMaterial, Category, Product, CartItem, Order,Sales,Customer
from django.contrib.auth.decorators import login_required
from django.views import View
from django.contrib.auth.models import User
from django.db import OperationalError, IntegrityError
from .forms import ProductForm, CategoryForm
from .models import Product, ProductRawMaterial,Category


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, 'ثبت نام با موفقیت انجام شد')
            return redirect('home')
        else:
            messages.error(request, 'لطفا خطاهای فرم را تصحیح کنید')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username_or_email = form.cleaned_data['username_or_email']
            password = form.cleaned_data['password']
            try:
                user = User.objects.get(username=username_or_email)
            except User.DoesNotExist:
                try:
                    user = User.objects.get(email=username_or_email)
                except User.DoesNotExist:
                    user = None
            
            if user is not None and user.check_password(password):
                login(request, user)
                if user.is_superuser:
                    return redirect('manage')
                else:
                    return redirect('home')
            else:
                messages.error(request, 'نام کاربری یا رمز عبور اشتباه است')
        else:
            messages.error(request, 'لطفا خطاهای فرم را تصحیح کنید')
    else:
        form = LoginForm()
    
    return render(request, 'login.html', {'form': form})
          
def logout_view(request):
    logout(request)
    messages.success(request,('با موفقیت خارح شدید'))
    return redirect('home')

def home(request):
    categories = Category.objects.all()
    return render(request, 'home.html', {'categories': categories})

def category_products(request, category_id):
    category = Category.objects.get(id=category_id)
    products = Product.objects.filter(category=category)
    return render(request, 'products.html', {'category': category, 'products': products})

