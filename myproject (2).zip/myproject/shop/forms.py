from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Product,RawMaterial,Category,Customer,ProductRawMaterial
class RegisterForm(UserCreationForm):
    email = forms.EmailField(label="ایمیل")
    fullname = forms.CharField(max_length=255, label="نام و نام خانوادگی")
    
    class Meta:
        model = User
        fields = ('username', 'fullname', 'email', 'password1', 'password2')
        labels = {
            'username': 'نام کاربری',
            'password1': 'رمز عبور',
            'password2': 'تکرار رمز عبور',
        }

    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)
        self.fields['username'].label = "نام کاربری"
        self.fields['username'].help_text = ""  
        self.fields['email'].label = "ایمیل"
        self.fields['fullname'].label = "نام و نام خانوادگی"
        self.fields['password1'].label = "رمز عبور"
        self.fields['password1'].help_text = "رمزی قوی انتخاب کنید."  
        self.fields['password2'].label = "تکرار رمز عبور"
        self.fields['password2'].help_text = "رمز عبور را دوباره وارد کنید."  
class LoginForm(forms.Form):
    username_or_email = forms.CharField(max_length=254, required=True, label="نام کاربری یا ایمیل")
    password = forms.CharField(widget=forms.PasswordInput, required=True, label="رمز عبور")

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'price', 'image']
        labels = {
            'name': 'نام محصول',
            'category': 'دسته‌بندی',
            'price': 'قیمت',
            'image': 'تصویر'
        }
class RawMaterialForm(forms.ModelForm):
    class Meta:
        model = RawMaterial
        fields = ['name', 'quantity']

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name']
class OrderTypeForm(forms.Form):
    ORDER_TYPES = [
        ('pickup', 'حضوری'),
        ('delivery', 'بیرون بر')
    ]
    order_type = forms.ChoiceField(choices=ORDER_TYPES, label='نوع سفارش')