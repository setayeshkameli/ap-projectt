from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class RawMaterial(models.Model):
    name = models.CharField(max_length=100, unique=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f'{self.name} ({self.quantity})'

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    fullname = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)

    def __str__(self):
        return self.fullname

class Product(models.Model):
    name = models.CharField(max_length=255, unique=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='uploads/product/')
    sold_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.name
class ProductRawMaterial(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='product_raw_materials')
    raw_material = models.ForeignKey(RawMaterial, on_delete=models.CASCADE)
    quantity_needed = models.PositiveIntegerField()
class CartItem(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE,default=0)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} of {self.product.name}"

class Order(models.Model):
    ORDER_TYPE_CHOICES = [
        ('take_out', 'Take Out'),
        ('in_person', 'In Person'),
    ]
    cart_items = models.ManyToManyField(CartItem)
    order_type = models.CharField(max_length=10, choices=ORDER_TYPE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    purchase_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE,default=0)

    def __str__(self):
        return f"Order {self.id} by Customer {self.customer.fullname}"

class Sales(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='sales')
    date = models.DateField()
    quantity = models.PositiveIntegerField()

    def __str__(self):
        return f'{self.product.name} - {self.quantity} on {self.date}'