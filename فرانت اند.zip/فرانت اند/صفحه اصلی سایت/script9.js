document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const cakeItem = this.closest('.cake-item');
            const cakeName = cakeItem.querySelector('h2').textContent;
            const cakePrice = cakeItem.querySelector('p').textContent;
            const cakeId = cakeItem.getAttribute('data-id');

            // Example: You can implement adding to cart functionality here
            console.log(Added ${cakeName} to cart. Price: ${cakePrice});
        });
    });
});
