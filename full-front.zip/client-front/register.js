document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Capture user inputs
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;

    // Simple client-side validation
    if (username === '' || password === '') {
        document.getElementById('reg-message').innerText = 'پر کردن همه فیلد ها الزامی است';
        return;
    }

    // Mock registration functionality
    document.getElementById('reg-message').innerText = 'ثبت نام با موفقیت انجام شد';
    document.getElementById('reg-message').style.color = 'green';
});
