document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const verticalMenu = document.getElementById('vertical-menu');
    const menuClose = document.getElementById('menu-close');
    const loginIcon = document.getElementById('login-icon');
    const logoutIcon = document.getElementById('logout-icon');
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    // Simulate a logged-in state
    let isLoggedIn = false; // Change this variable to simulate login/logout

    function updateAuthIcons() {
        if (isLoggedIn) {
            loginIcon.style.display = 'none';
            logoutIcon.style.display = 'block';
        } else {
            loginIcon.style.display = 'block';
            logoutIcon.style.display = 'none';
        }
    }

    menuToggle.addEventListener('click', () => {
        verticalMenu.classList.toggle('show');
    });

    menuClose.addEventListener('click', () => {
        verticalMenu.classList.remove('show');
    });

    const optionToggles = document.querySelectorAll('.toggle-options');
    
    optionToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const options = toggle.nextElementSibling;
            options.classList.toggle('show');
            if (options.classList.contains('show')) {
                toggle.textContent = '<';
            } else {
                toggle.textContent = '>';
            }
        });
    });

    // Initialize icons based on logged-in state
    updateAuthIcons();

    // Example event listeners to toggle logged-in state
    loginIcon.addEventListener('click', () => {
        isLoggedIn = true;
        updateAuthIcons();
    });

    logoutIcon.addEventListener('click', () => {
        isLoggedIn = false;
        updateAuthIcons();
    });

    // Slider functionality
    let slideIndex = 0;
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;

    function showSlide(index) {
        if (index >= totalSlides) {
            slideIndex = 0;
        } else if (index < 0) {
            slideIndex = totalSlides - 1;
        } else {
            slideIndex = index;
        }
        slides.style.transform = `translateX(${-slideIndex * 100}%)`;
    }

    document.querySelector('.prev').addEventListener('click', () => {
        showSlide(slideIndex - 1);
    });

    document.querySelector('.next').addEventListener('click', () => {
        showSlide(slideIndex + 1);
    });

    // Automatic sliding
    setInterval(() => {
        showSlide(slideIndex + 1);
    }, 3000);

    // Cart functionality
    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const item = button.getAttribute('data-item');
            addToCart(item);
        });
    });

    function addToCart(item) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const existingItem = cart.find(cartItem => cartItem.name === item);

        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ name: item, quantity: 1 });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
        alert(`${item} به سبد خرید اضافه شد`);
    }
});
