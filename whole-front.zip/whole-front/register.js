document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;

    
    if (username === '' || password === '') {
        document.getElementById('reg-message').innerText = 'پر کردن همه فیلد ها الزامی است';
        return;
    }

    
    document.getElementById('reg-message').innerText = 'ثبت نام با موفقیت انجام شد';
    document.getElementById('reg-message').style.color = 'green';
});
