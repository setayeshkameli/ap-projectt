document.getElementById('product-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let productName = document.getElementById('product-name').value;
    let rawMaterials = document.getElementById('raw-materials').value;
    let category = document.getElementById('category').value;
    let price = document.getElementById('price').value;
    let productImage = document.getElementById('product-image').files[0];

    let reader = new FileReader();
    reader.onload = function(e) {
        let productImageURL = e.target.result;

       
        let newProduct = {
            name: productName,
            rawMaterials: rawMaterials,
            category: category,
            price: price,
            image: productImageURL
        };

        
        let products = JSON.parse(localStorage.getItem('products')) || [];

        
        products.push(newProduct);

        
        localStorage.setItem('products', JSON.stringify(products));

        
        renderProductList();

        
        document.getElementById('product-form').reset();
    }

    reader.readAsDataURL(productImage);
});


document.addEventListener('DOMContentLoaded', () => {
    renderProductList();
});

function renderProductList() {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    let products = JSON.parse(localStorage.getItem('products')) || [];

    products.forEach((product, index) => {
        let productListItem = document.createElement('li');

        let productImageElement = document.createElement('img');
        productImageElement.src = product.image;

        let productInfo = document.createElement('div');
        productInfo.innerHTML = `
            <strong>${product.name}</strong><br>
            مواد اولیه: ${product.rawMaterials}<br>
            دسته: ${product.category}<br>
            قیمت: تومان${product.price}
        `;

        let deleteButton = document.createElement('button');
        deleteButton.textContent = 'حذف';
        deleteButton.addEventListener('click', () => {
            deleteProduct(index);
        });

        productListItem.appendChild(productImageElement);
        productListItem.appendChild(productInfo);
        productListItem.appendChild(deleteButton);

        productList.appendChild(productListItem);
    });
}

function deleteProduct(index) {
    let products = JSON.parse(localStorage.getItem('products')) || [];
    products.splice(index, 1);
    localStorage.setItem('products', JSON.stringify(products));
    renderProductList();
}
