document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    
    if (username === '' || password === '') {
        document.getElementById('message').innerText = 'پر کردن همه فیلد ها الزامی است';
        return;
    }

    
    if (username === 'user' && password === 'password') {
        document.getElementById('message').innerText = 'ورود با موفقیت انجام شد';
        document.getElementById('message').style.color = 'green';
    } else {
        document.getElementById('message').innerText = 'نام کاربری و یا رمز عبور اشتباه است';
    }
});
