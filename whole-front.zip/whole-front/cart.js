document.addEventListener('DOMContentLoaded', () => {
    const cartContainer = document.getElementById('cart');

    function renderCart() {
        cartContainer.innerHTML = '';
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        let total = 0;

        if (cart.length === 0) {
            cartContainer.innerHTML = '<p>سبد خرید شما خالی است.</p>';
            return;
        }

        cart.forEach((item, index) => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');

            itemElement.innerHTML = `
                <p>${item.name} (x${item.quantity})</p>
                <button class="delete-button" data-index="${index}">حذف</button>
            `;

            total += item.price * item.quantity;
            cartContainer.appendChild(itemElement);
        });

        const totalElement = document.createElement('div');
        totalElement.classList.add('cart-item');
        totalElement.innerHTML = `
            <p>مجموع: تومان${total.toFixed(2)}</p>
        `;
        cartContainer.appendChild(totalElement);

        document.querySelectorAll('.delete-button').forEach(button => {
            button.addEventListener('click', () => {
                const index = button.getAttribute('data-index');
                removeFromCart(index);
            });
        });
    }

    function removeFromCart(index) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        renderCart();
    }

    renderCart();

    document.getElementById('transfer-button').addEventListener('click', () => {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (cart.length === 0) {
            alert('سبد خرید شما خالی است.');
            return;
        }

        const orderType = document.querySelector('input[name="order-type"]:checked').value;
        const orders = JSON.parse(localStorage.getItem('orders')) || [];

        cart.forEach(item => {
            orders.push({
                name: item.name,
                quantity: item.quantity,
                date: new Date().toLocaleDateString('fa-IR'),
                type: orderType
            });
        });

        localStorage.setItem('orders', JSON.stringify(orders));
        localStorage.removeItem('cart');
        alert(`نوع سفارش: ${orderType}\nدر حال انتقال به صفحه پرداخت...`);
        window.location.href = 'index.html';
    });
});
