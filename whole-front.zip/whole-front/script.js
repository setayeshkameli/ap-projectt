document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const verticalMenu = document.getElementById('vertical-menu');
    const menuClose = document.getElementById('menu-close');
    const loginIcon = document.getElementById('login-icon');
    const logoutIcon = document.getElementById('logout-icon');
    const navigateButtons = document.querySelectorAll('.navigate');

    let isLoggedIn = false;

    function updateAuthIcons() {
        if (isLoggedIn) {
            loginIcon.style.display = 'none';
            logoutIcon.style.display = 'block';
        } else {
            loginIcon.style.display = 'block';
            logoutIcon.style.display = 'none';
        }
    }

    menuToggle.addEventListener('click', () => {
        verticalMenu.classList.toggle('show');
    });

    menuClose.addEventListener('click', () => {
        verticalMenu.classList.remove('show');
    });

    navigateButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            event.preventDefault();
            const targetSection = button.getAttribute('data-item');
            localStorage.setItem('targetSection', targetSection);
            window.location.href = button.getAttribute('href');
        });
    });

    updateAuthIcons();

    loginIcon.addEventListener('click', () => {
        isLoggedIn = true;
        updateAuthIcons();
    });

    logoutIcon.addEventListener('click', () => {
        isLoggedIn = false;
        updateAuthIcons();
    });

    let slideIndex = 0;
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;

    function showSlide(index) {
        if (index >= totalSlides) {
            slideIndex = 0;
        } else if (index < 0) {
            slideIndex = totalSlides - 1;
        } else {
            slideIndex = index;
        }
        slides.style.transform = `translateX(${-slideIndex * 100}%)`;
    }

    document.querySelector('.prev').addEventListener('click', () => {
        showSlide(slideIndex - 1);
    });

    document.querySelector('.next').addEventListener('click', () => {
        showSlide(slideIndex + 1);
    });

    setInterval(() => {
        showSlide(slideIndex + 1);
    }, 3000);
});
